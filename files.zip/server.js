/* =========================================================
   server.js — Entry point. Wires every route module together.
   Run with: npm start  (after creating .env from .env.example)
   ========================================================= */

require("dotenv").config();
const express = require("express");
const cors = require("cors");

const { router: authRouter } = require("./src/routes/auth");
const taskRouter = require("./src/routes/tasks");
const aiRouter = require("./src/routes/ai");
const calendarRouter = require("./src/routes/calendar");
const autopilotRouter = require("./src/routes/autopilot");

const app = express();

app.use(cors());
app.use(express.json());

app.use("/api/auth", authRouter);
app.use("/api/tasks", taskRouter);
app.use("/api/ai", aiRouter);
app.use("/api/calendar", calendarRouter);
app.use("/api/autopilot", autopilotRouter);

app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    aiConfigured: !!process.env.ANTHROPIC_API_KEY,
    calendarConfigured: !!(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET),
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log("Runway server listening on http://localhost:" + PORT);
});
